package vista;

/**
 *
 * @author Ivan Sierra Arrieta - 0222420035
 */
public class Veterinaria {
    public static void menu(){ 
        
    }
}
